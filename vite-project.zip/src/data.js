export const data = [
  {
    title: "burger",
    price: 100,
  },
  {
    title: "burger2",
    price: 200,
  },
  {
    title: "burger3",
    price: 300,
  },
];
