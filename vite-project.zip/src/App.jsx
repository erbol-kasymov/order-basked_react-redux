import React from "react";
import "./App.css";
import { OrderBasket } from "./components/Orders-basket";

function App() {
  return (
    <>
      <OrderBasket />
    </>
  );
}

export default App;
